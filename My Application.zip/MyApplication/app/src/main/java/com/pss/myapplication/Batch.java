package com.pss.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

public class Batch extends AppCompatActivity {

    private RecyclerView dataBatch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_batch);

        dataBatch = findViewById(R.id.dataBatch);
        dataBatch.setLayoutManager(new LinearLayoutManager(this));
        
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    public void addBatch(View view)
    {
        startActivity(new Intent(Batch.this, ManageBatch.class).putExtra("action","add"));
    }
}